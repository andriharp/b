# BehVar
individual variability in decision making
